# SD Bagpipe Tuner - Android project

## Open
1. Install Android Studio.
2. Choose **Open** and select this folder.
3. Let Gradle sync.
4. Connect your Android phone with USB debugging enabled.
5. Press Run.

## Features
- Native Android microphone capture with AudioRecord
- Chanter / Tenor / Bass modes
- Low A calibration
- Hz and cents display
- Highland-style note targets
- Offline processing

## Next engineering step
For Braw-like performance, test with real Highland bagpipe recordings and improve the DSP with:
- harmonic-aware fundamental selection
- adaptive band-pass filters
- drone/chanter source separation
- pitch confidence
- ornament-aware note tracking
