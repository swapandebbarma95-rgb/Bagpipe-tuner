# SD Bagpipe Tuner — GitHub APK Build

This project includes a GitHub Actions workflow that builds the Android APK in the cloud, so you can use an Android tablet without installing Android Studio.

## Build from your tablet

1. Create a GitHub account and a new repository.
2. Upload all files and folders from this project to the repository.
3. Open **Actions** → **Build Android APK** → **Run workflow**.
4. Wait for the build to finish.
5. Open the completed workflow run.
6. Under **Artifacts**, download **SD-Bagpipe-Tuner-debug-apk**.
7. Extract the downloaded ZIP and install `app-debug.apk` on your tablet.

The workflow builds a debug APK. It does not publish the app to Google Play.
