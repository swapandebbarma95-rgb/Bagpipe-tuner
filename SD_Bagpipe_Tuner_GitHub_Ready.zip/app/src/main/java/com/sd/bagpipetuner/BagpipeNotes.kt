package com.sd.bagpipetuner

import kotlin.math.pow

data class BagpipeNote(val name: String, val ratio: Double)

object BagpipeNotes {
    val notes = listOf(
        BagpipeNote("Low G", 2.0.pow(-2.0 / 12.0)),
        BagpipeNote("Low A", 1.0),
        BagpipeNote("B", 2.0.pow(2.0 / 12.0)),
        BagpipeNote("C", 2.0.pow(3.0 / 12.0)),
        BagpipeNote("D", 2.0.pow(5.0 / 12.0)),
        BagpipeNote("E", 2.0.pow(7.0 / 12.0)),
        BagpipeNote("F", 2.0.pow(8.0 / 12.0)),
        BagpipeNote("High G", 2.0.pow(10.0 / 12.0)),
        BagpipeNote("High A", 2.0)
    )

    fun nearest(freq: Double, lowA: Double): Pair<BagpipeNote, Double> {
        return notes.minByOrNull {
            kotlin.math.abs(1200.0 * kotlin.math.log2(freq / (lowA * it.ratio)))
        }!!.let { it to lowA * it.ratio }
    }
}
