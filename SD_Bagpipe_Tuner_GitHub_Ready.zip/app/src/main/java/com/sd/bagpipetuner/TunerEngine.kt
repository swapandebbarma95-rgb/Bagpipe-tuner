package com.sd.bagpipetuner

import kotlin.math.*

class TunerEngine {
    private var lastFrequency = 0.0

    fun detect(samples: ShortArray, sampleRate: Int): Double {
        if (samples.isEmpty()) return -1.0

        val x = DoubleArray(samples.size)
        var rms = 0.0
        for (i in samples.indices) {
            x[i] = samples[i] / 32768.0
            rms += x[i] * x[i]
        }
        rms = sqrt(rms / samples.size)
        if (rms < 0.008) return -1.0

        val minLag = max(20, (sampleRate / 1400.0).toInt())
        val maxLag = min(samples.size - 2, (sampleRate / 55.0).toInt())

        var bestLag = -1
        var bestCorr = -1.0

        for (lag in minLag..maxLag) {
            var xy = 0.0
            var xx = 0.0
            var yy = 0.0
            for (i in 0 until samples.size - lag) {
                val a = x[i]
                val b = x[i + lag]
                xy += a * b
                xx += a * a
                yy += b * b
            }
            val corr = if (xx > 0 && yy > 0) xy / sqrt(xx * yy) else 0.0
            if (corr > bestCorr) {
                bestCorr = corr
                bestLag = lag
            }
        }

        if (bestLag <= 0 || bestCorr < 0.15) return -1.0

        val f = sampleRate.toDouble() / bestLag
        if (f !in 55.0..1500.0) return -1.0

        lastFrequency = if (lastFrequency == 0.0) f else lastFrequency * .65 + f * .35
        return lastFrequency
    }

    fun cents(measured: Double, target: Double): Double =
        if (measured > 0 && target > 0) 1200.0 * log2(measured / target) else 0.0
}
