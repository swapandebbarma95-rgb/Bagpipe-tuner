package com.sd.bagpipetuner

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) startRecording() }

    private var record: AudioRecord? = null
    private var job: Job? = null
    private val engine = TunerEngine()

    private val _frequency = mutableStateOf(0.0)
    private val _running = mutableStateOf(false)
    private val _mode = mutableStateOf("Chanter")
    private val _lowA = mutableStateOf(466.16)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }

    private fun toggle() {
        if (_running.value) stopRecording()
        else if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED) startRecording()
        else permission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startRecording() {
        val sr = 48000
        val min = AudioRecord.getMinBufferSize(
            sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        record = AudioRecord(
            MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 8192)
        )
        record!!.startRecording()
        _running.value = true
        job = CoroutineScope(Dispatchers.Default).launch {
            val buffer = ShortArray(4096)
            while (isActive && _running.value) {
                val n = record?.read(buffer, 0, buffer.size) ?: 0
                if (n > 0) {
                    val f = engine.detect(if (n == buffer.size) buffer else buffer.copyOf(n), sr)
                    if (f > 0) withContext(Dispatchers.Main) { _frequency.value = f }
                }
            }
        }
    }

    private fun stopRecording() {
        _running.value = false
        job?.cancel()
        record?.stop()
        record?.release()
        record = null
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }

    @Composable
    fun App() {
        val freq by _frequency
        val running by _running
        val mode by _mode
        val lowA by _lowA
        var tab by remember { mutableStateOf(0) }

        val target = when (mode) {
            "Tenor" -> lowA / 2.0
            "Bass" -> lowA / 4.0
            else -> if (freq > 0) BagpipeNotes.nearest(freq, lowA).second else lowA
        }
        val note = if (mode == "Chanter" && freq > 0)
            BagpipeNotes.nearest(freq, lowA).first.name else mode.uppercase()
        val cents = if (freq > 0) engine.cents(freq, target) else 0.0

        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF080D18)) {
            Column(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("🎵 SD Bagpipe Tuner", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Android V1 • native microphone tuner", color = Color(0xFF94A3B8))
                Spacer(Modifier.height(14.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Chanter","Tenor","Bass").forEachIndexed { i, s ->
                        Button(
                            onClick = { tab = i; _mode.value = s },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tab == i) Color(0xFF2563EB) else Color(0xFF1E293B)
                            )
                        ) { Text(s) }
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827))
                ) {
                    Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(note, color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Black)
                        Text(if (freq > 0) "%.2f Hz  •  target %.2f Hz".format(freq, target) else "Play a steady note",
                            color = Color(0xFF94A3B8))
                        Spacer(Modifier.height(18.dp))
                        Box(Modifier.fillMaxWidth().height(18.dp).background(Color(0xFF26324D), RoundedCornerShape(20.dp))) {
                            Box(
                                Modifier.fillMaxHeight().width(5.dp)
                                    .offset(x = ((cents.coerceIn(-50.0,50.0) + 50.0) / 100.0 * 300.0).dp)
                                    .background(Color.White, RoundedCornerShape(4.dp))
                            )
                        }
                        Text("%+.1f cents".format(cents), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp))
                        Text(
                            if (freq <= 0) "Waiting" else if (abs(cents) <= 5) "IN TUNE ✓" else if (cents < 0) "FLAT ←" else "SHARP →",
                            color = if (abs(cents) <= 5 && freq > 0) Color(0xFF4ADE80) else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { toggle() }, modifier = Modifier.weight(1f)) {
                        Text(if (running) "⏹ Stop" else "🎙 Start")
                    }
                    OutlinedButton(onClick = { if (freq > 0 && _mode.value == "Chanter") _lowA.value = freq },
                        modifier = Modifier.weight(1f)) { Text("🎯 Calibrate A") }
                }
                Spacer(Modifier.height(10.dp))
                Text("Low A reference: %.2f Hz".format(lowA), color = Color(0xFFCBD5E1))
                Text("Microphone: ${if (running) "ON" else "OFF"}", color = Color(0xFF94A3B8), modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(12.dp))
                Text(
                    "This is an independent prototype. A single phone microphone receives the mixed bagpipe sound; true Braw-style independent chanter/tenor/bass separation requires additional calibrated DSP and real-pipe testing.",
                    color = Color(0xFF94A3B8), fontSize = 12.sp
                )
            }
        }
    }
}
